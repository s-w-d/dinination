package net.minpuro.divinationnow01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonStart;  //「スタート」ボタン
    Button buttonCaution;  //「注意事項」

    int id;
    Intent intent;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        buttonStart = findViewById(R.id.buttonStart);
        buttonCaution = findViewById(R.id.buttonCaution);

        buttonStart.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (id == R.id.buttonStart) {
            //「スタート」を押したとき
            intent = new Intent(FirstActivity.this, MainActivity.class);
            startActivity(intent);

        } else if (id == R.id.buttonCaution) {
            //「注意事項」を押したとき
            intent = new Intent(FirstActivity.this, CautionActivity.class);
            intent.putExtra("caution", 1);
            startActivity(intent);

        }

    }
}
