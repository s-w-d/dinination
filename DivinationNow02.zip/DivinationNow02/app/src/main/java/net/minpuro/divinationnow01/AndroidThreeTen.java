package net.minpuro.divinationnow01;

class AndroidThreeTen {
    public static void init(MainActivity mainActivity) {
    }
}
