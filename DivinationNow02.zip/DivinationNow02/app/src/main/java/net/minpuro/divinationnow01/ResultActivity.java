package net.minpuro.divinationnow01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewName;
    TextView textViewOmikuji;
    TextView textViewResult;
    Button buttonBack;
    Button buttonCaution;

    int id;
    Intent intent;
    Bundle bundle;
    String name;  //入力された名前
    int personalData;  //入力された個人情報

    Date date;
    DateFormat dateFormat;
    int hour;  //取得した「時間」

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        textViewName = findViewById(R.id.textViewName);
        textViewOmikuji = findViewById(R.id.textViewOmikuji);
        textViewResult = findViewById(R.id.textViewResult);
        buttonBack = findViewById(R.id.buttonBack);
        buttonCaution = findViewById(R.id.buttonCaution);

        buttonBack.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);


        intent = getIntent();
        bundle = intent.getExtras();
        name = bundle.getString("name");
        personalData = bundle.getInt("personalData");

        textViewName.setText(String.valueOf(name));

        personalData();

    }

    private void personalData() {
        //個人情報で出す結果を変える
        if (personalData >= 8) {
            textViewOmikuji.setText("大吉!");
        } else if (personalData >= 6) {
            textViewOmikuji.setText("中吉です");
        } else if (personalData >= 4) {
            textViewOmikuji.setText("小吉です");
        } else if (personalData >= 2) {
            textViewOmikuji.setText("吉です");
        } else {
            textViewOmikuji.setText("末吉です");
        }


        date = new Date(System.currentTimeMillis());
        dateFormat = new SimpleDateFormat("HH");
        hour = Integer.parseInt(dateFormat.format(date));

        if (hour >= 20 && hour < 24) {
            textViewResult.setText("今日も1日お疲れ様でした");
        } else if (hour >= 17 && hour < 20) {
            textViewResult.setText("晩御飯は楽しい時間♪");
        } else if (hour >= 14 && hour < 17) {
            textViewResult.setText("あと少しです！がんばりましょう！");
        } else if (hour >= 12 && hour < 14) {
            textViewResult.setText("お昼ご飯は何にしようかな♪");
        } else if (hour >= 9 && hour < 12) {
            textViewResult.setText("今日も1日頑張りましょう！！");
        } else if (hour >= 6 && hour < 9) {
            textViewResult.setText("おはようございます！");
        } else if (hour >= 4 && hour < 6) {
            textViewResult.setText("早起きは3文の得です");
        } else {
            textViewResult.setText("遅くまでご苦労様です");
        }

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (id == R.id.buttonBack) {
            finish();
        } else if (id == R.id.buttonCaution) {
            intent = new Intent(ResultActivity.this, CautionActivity.class);
            intent.putExtra("caution", 3);
            startActivity(intent);
        }

    }

}