package net.minpuro.divinationnow01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editTextYear;  //西暦

    Spinner spinnerMonth;  //月
    Spinner spinnerDay;  //日

    EditText editTextName;  //名前

    Button buttonDinination;  //「占う」ボタン
    Button buttonCaution;  //「注意事項」

    int id;
    Intent intent;
    int year;  //入力された西暦をint型にしたもの
    String strYear;  //入力された西暦の値
    int month;  //スピナーで選んだ月
    int day;  //スピナーで選んだ日
    int mimute;  //取得した「分」
    String name;  //入力された名前
    int nameinfo;  //名前を数値化
    int personalData;  //入力された個人情報のまとめ

    ArrayAdapter<Integer> arrayAdapterMonth;
    ArrayAdapter<Integer> arrayAdapterDay;

    Date date;
    DateFormat dateFormat;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextYear = findViewById(R.id.editTextYear);
        spinnerMonth = findViewById(R.id.spinnerMonth);
        spinnerDay = findViewById(R.id.spinnerDay);
        editTextName = findViewById(R.id.editTextName);
        buttonDinination = findViewById(R.id.buttonDinination);
        buttonCaution = findViewById(R.id.buttonCaution);

        buttonDinination.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

        arrayAdapterMonth();
        arrayAdapterDay();

        date = new Date(System.currentTimeMillis());
        dateFormat = new SimpleDateFormat("HH");


    }

    private void arrayAdapterDay() {
        arrayAdapterDay = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item);
        arrayAdapterDay.add(1);
        arrayAdapterDay.add(2);
        arrayAdapterDay.add(3);
        arrayAdapterDay.add(4);
        arrayAdapterDay.add(5);
        arrayAdapterDay.add(6);
        arrayAdapterDay.add(7);
        arrayAdapterDay.add(8);
        arrayAdapterDay.add(9);
        arrayAdapterDay.add(10);
        arrayAdapterDay.add(11);
        arrayAdapterDay.add(12);
        arrayAdapterDay.add(13);
        arrayAdapterDay.add(14);
        arrayAdapterDay.add(15);
        arrayAdapterDay.add(16);
        arrayAdapterDay.add(17);
        arrayAdapterDay.add(18);
        arrayAdapterDay.add(19);
        arrayAdapterDay.add(20);
        arrayAdapterDay.add(21);
        arrayAdapterDay.add(22);
        arrayAdapterDay.add(23);
        arrayAdapterDay.add(24);
        arrayAdapterDay.add(25);
        arrayAdapterDay.add(26);
        arrayAdapterDay.add(27);
        arrayAdapterDay.add(28);
        arrayAdapterDay.add(29);
        arrayAdapterDay.add(30);
        arrayAdapterDay.add(31);
        spinnerDay.setAdapter(arrayAdapterDay);
    }

    private void arrayAdapterMonth() {
        arrayAdapterMonth = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item);
        arrayAdapterMonth.add(1);
        arrayAdapterMonth.add(2);
        arrayAdapterMonth.add(3);
        arrayAdapterMonth.add(4);
        arrayAdapterMonth.add(5);
        arrayAdapterMonth.add(6);
        arrayAdapterMonth.add(7);
        arrayAdapterMonth.add(8);
        arrayAdapterMonth.add(9);
        arrayAdapterMonth.add(10);
        arrayAdapterMonth.add(11);
        arrayAdapterMonth.add(12);
        spinnerMonth.setAdapter(arrayAdapterMonth);
    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        strYear = String.valueOf(editTextYear.getText());
        name = String.valueOf(editTextName.getText());


        if (id == R.id.buttonDinination) {

            if (!strYear.equals("") && strYear != null
                    && !name.equals("") && name != null) {
                //「占う」ボタンを押したとき
                dinination();
            }

        } else if (id == R.id.buttonCaution) {
            //「注意事項」
            intent = new Intent(MainActivity.this, CautionActivity.class);
            intent.putExtra("caution", 2);
            startActivity(intent);
        }

    }

    private void dinination() {
        year = Integer.parseInt(String.valueOf(editTextYear.getText()));
        month = (int) spinnerMonth.getSelectedItem();
        day = (int) spinnerDay.getSelectedItem();
        mimute = Integer.parseInt(dateFormat.format(date));

        name = String.valueOf(editTextName.getText());
        nameinfo = 0;

        char[] c = name.toCharArray();
        for(int i : c) {
            nameinfo += i;
        }

        //「personalData」
        personalData = ((year + month + day + nameinfo) % 10) + (mimute % 10);


        intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("personalData", personalData);
        intent.putExtra("name", name);
        startActivity(intent);

    }

}
