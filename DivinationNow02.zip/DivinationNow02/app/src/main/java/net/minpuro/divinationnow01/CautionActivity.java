package net.minpuro.divinationnow01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CautionActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonPrevios;

    int id;
    Intent intent;
    Bundle bundle;
    int caution;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caution);

        buttonPrevios = findViewById(R.id.buttonPrevious);

        buttonPrevios.setOnClickListener(this);


        intent = getIntent();
        bundle = intent.getExtras();
        caution = bundle.getInt("caution");

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (id == R.id.buttonPrevious) {
            if (caution == 1) {
                finish();
            } else if (caution == 2) {
                finish();
            } else if (caution == 3) {
                finish();
            }
        }

    }
}
