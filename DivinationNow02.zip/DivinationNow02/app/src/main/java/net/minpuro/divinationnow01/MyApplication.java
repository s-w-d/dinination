package net.minpuro.divinationnow01;

import android.app.Application;

public class MyApplication extends Application {
}
